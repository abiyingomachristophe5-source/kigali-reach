/* ═══════════════════════════════════════════
   KIGALI REACH — script.js
   Cart, Wishlist, Language, Currency,
   Carousel, Countdown, Modals, Toast
═══════════════════════════════════════════ */

/* ── LANGUAGE ── */
const TRANSLATIONS = {
  en: {
    searchPlaceholder: "Search products... / Shakisha ibicuruzwa...",
    shopByCategory: "Shop by Category",
    shopByCategorySub: "Browse our curated collections",
    bestSellers: "Best Sellers",
    bestSellersSub: "Our most loved products",
    newArrivals: "New Arrivals",
    newArrivalsSub: "Fresh drops this week",
    flashDeals: "Flash Deals — Ends Soon!",
    viewAll: "View All →",
    viewAllDeals: "View All Deals →",
    addToCart: "Add to Cart",
    soldOut: "Sold Out",
    inStock: "In Stock",
    outOfStock: "Sold Out",
    trustTitle: "Why Shop With Us",
    appTitle: "Shop Faster on Our App!",
    appSub: "Get exclusive deals, track orders, and enjoy a smoother shopping experience on our app.",
    reviewsTitle: "What Our Customers Say",
    newsletterTitle: "Get Exclusive Deals in Your Inbox!",
    newsletterSub: "Subscribe and get 15% off your first order",
    newsletterBtn: "Subscribe",
    waTitle: "Join Our WhatsApp Group!",
    waSub: "Get flash deals, new arrivals and offers directly on WhatsApp",
    waBtn: "Join Now",
    save: "Save",
    endsIn: "Ends in",
    days: "Days", hours: "Hrs", mins: "Min", secs: "Sec"
  },
  rw: {
    searchPlaceholder: "Shakisha ibicuruzwa...",
    shopByCategory: "Gura Ukurikije Ubwoko",
    shopByCategorySub: "Reba ibyiciro byacu",
    bestSellers: "Ibicuruzwa Bikunzwe",
    bestSellersSub: "Ibicuruzwa bikunzwe cyane",
    newArrivals: "Bishya kuri Marike",
    newArrivalsSub: "Ibishya bya buri cyumweru",
    flashDeals: "Ibiciro Biratashye!",
    viewAll: "Reba Byose →",
    viewAllDeals: "Reba Amasezerano Yose →",
    addToCart: "Shyira mu Agakoba",
    soldOut: "Birangiye",
    inStock: "Bihari",
    outOfStock: "Birangiye",
    trustTitle: "Impamvu Utumikirira",
    appTitle: "Gura Vuba Ukoresheje App Yacu!",
    appSub: "Bonera amasezerano yihariye, kureba zamówienia, no gutura neza ukoresheje app yacu.",
    reviewsTitle: "Ibyo Abakiriya Bacu Bavuga",
    newsletterTitle: "Bonera Amakuru y'Amasezerano mu Email!",
    newsletterSub: "Iyandikishe ukabona 15% kongerwa ku itumiza rya mbere",
    newsletterBtn: "Iyandikishe",
    waTitle: "Injira mu Itsinda ryacu rya WhatsApp!",
    waSub: "Bonera amasezerano, ibishya, n'amatangazo muri WhatsApp",
    waBtn: "Injira Ubu",
    save: "Bonera",
    endsIn: "Irangira mu",
    days: "Iminsi", hours: "Amasaha", mins: "Iminota", secs: "Inzegamira"
  }
};

let currentLang = localStorage.getItem("kr_lang") || "en";
let currentCurrency = localStorage.getItem("kr_currency") || "RWF";
const USD_RATE = 1300;

function t(key) { return (TRANSLATIONS[currentLang] || TRANSLATIONS.en)[key] || key; }

function formatPrice(rwf) {
  if (currentCurrency === "USD") {
    return "$" + (rwf / USD_RATE).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
  return rwf.toLocaleString() + " RWF";
}

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem("kr_lang", lang);
  document.querySelectorAll("[data-lang-btn]").forEach(b => {
    b.classList.toggle("active", b.dataset.langBtn === lang);
  });
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (key) el.textContent = t(key);
  });
  document.querySelectorAll("[data-i18n-ph]").forEach(el => {
    el.placeholder = t(el.dataset.i18nPh);
  });
  refreshPrices();
}

function setCurrency(cur) {
  currentCurrency = cur;
  localStorage.setItem("kr_currency", cur);
  document.querySelectorAll("[data-cur-btn]").forEach(b => {
    b.classList.toggle("active", b.dataset.curBtn === cur);
  });
  refreshPrices();
}

function refreshPrices() {
  document.querySelectorAll("[data-price]").forEach(el => {
    el.textContent = formatPrice(Number(el.dataset.price));
  });
  document.querySelectorAll("[data-orig-price]").forEach(el => {
    el.textContent = formatPrice(Number(el.dataset.origPrice));
  });
}

/* ── CART ── */
const CART_KEY = "kigali_cart";

function getCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch { return []; }
}
function saveCart(c) {
  localStorage.setItem(CART_KEY, JSON.stringify(c));
  updateCartBadge();
}
function addToCart(id, name, price, image, category) {
  const cart = getCart();
  const ex = cart.find(i => i.id === id);
  if (ex) ex.qty += 1;
  else cart.push({ id, name, price, image, category, qty: 1 });
  saveCart(cart);
  showToast(name + " added to cart");
}
function removeFromCart(id) {
  saveCart(getCart().filter(i => i.id !== id));
  if (typeof renderCart === "function") renderCart();
}
function updateQty(id, delta) {
  const c = getCart();
  const item = c.find(i => i.id === id);
  if (!item) return;
  item.qty = Math.max(1, item.qty + delta);
  saveCart(c);
  if (typeof renderCart === "function") renderCart();
}
function clearCart() {
  saveCart([]);
  if (typeof renderCart === "function") renderCart();
}
function updateCartBadge() {
  const count = getCart().reduce((s, i) => s + i.qty, 0);
  document.querySelectorAll(".cart-count").forEach(el => el.textContent = count);
}

/* ── WISHLIST ── */
const WL_KEY = "kigali_wishlist";
function getWishlist() {
  try { return JSON.parse(localStorage.getItem(WL_KEY)) || []; } catch { return []; }
}
function saveWishlist(w) {
  localStorage.setItem(WL_KEY, JSON.stringify(w));
  updateWishlistBadge();
}
function toggleWishlist(id, name, price, image, category) {
  const wl = getWishlist();
  const ex = wl.findIndex(i => i.id === id);
  if (ex >= 0) {
    wl.splice(ex, 1);
    showToast(name + " removed from wishlist");
  } else {
    wl.push({ id, name, price, image, category, qty: 1 });
    showToast(name + " added to wishlist", "success");
  }
  saveWishlist(wl);
  document.querySelectorAll('[data-wl-id="' + id + '"]').forEach(btn => {
    btn.classList.toggle("active", wl.some(i => i.id === id));
  });
}
function isInWishlist(id) { return getWishlist().some(i => i.id === id); }
function updateWishlistBadge() {
  const count = getWishlist().length;
  document.querySelectorAll(".wl-count").forEach(el => el.textContent = count);
}

/* ── TOAST ── */
function showToast(msg, type = "default") {
  const c = document.getElementById("toast-container");
  if (!c) return;
  const d = document.createElement("div");
  d.className = "toast" + (type !== "default" ? " " + type : "");
  const icon = type === "success"
    ? '<path d="M20 6L9 17l-5-5"/>'
    : '<path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>';
  d.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${icon}</svg><span>${msg}</span>`;
  c.appendChild(d);
  setTimeout(() => { d.style.opacity="0"; d.style.transform="translateX(20px)"; d.style.transition="all .3s"; setTimeout(() => d.remove(), 300); }, 3200);
}

/* ── MODALS ── */
function openModal(id)  { const el=document.getElementById(id); if(el) el.classList.add("open"); }
function closeModal(id) { const el=document.getElementById(id); if(el) el.classList.remove("open"); }
function openLogin()  { closeModal("signupModal"); openModal("loginModal"); }
function openSignup() { closeModal("loginModal");  openModal("signupModal"); }

/* ── MOBILE SIDEBAR ── */
function openSidebar() {
  document.getElementById("mobileSidebar")?.classList.add("open");
  document.getElementById("sidebarOverlay")?.classList.add("open");
}
function closeSidebar() {
  document.getElementById("mobileSidebar")?.classList.remove("open");
  document.getElementById("sidebarOverlay")?.classList.remove("open");
}

/* ── CAROUSEL ── */
function initCarousel() {
  const slides = document.querySelectorAll(".hero-slide");
  const dots   = document.querySelectorAll(".hero-dot");
  if (!slides.length) return;
  let cur = 0, timer;

  function goTo(n) {
    slides[cur].classList.remove("active");
    dots[cur]?.classList.remove("active");
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add("active");
    dots[cur]?.classList.add("active");
  }
  function start() { timer = setInterval(() => goTo(cur + 1), 4000); }
  function reset() { clearInterval(timer); start(); }

  document.querySelector(".hero-prev")?.addEventListener("click", () => { goTo(cur - 1); reset(); });
  document.querySelector(".hero-next")?.addEventListener("click", () => { goTo(cur + 1); reset(); });
  dots.forEach((d, i) => d.addEventListener("click", () => { goTo(i); reset(); }));
  slides[0].classList.add("active");
  dots[0]?.classList.add("active");
  start();
}

/* ── COUNTDOWN ── */
function initCountdown(targetKey) {
  const stored = localStorage.getItem(targetKey);
  let end;
  if (stored && Number(stored) > Date.now()) {
    end = Number(stored);
  } else {
    end = Date.now() + 23 * 3600000 + 59 * 60000 + 59000;
    localStorage.setItem(targetKey, end);
  }

  function tick() {
    const diff = Math.max(0, end - Date.now());
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    const set = (id, v) => { const el=document.getElementById(id); if(el) el.textContent=String(v).padStart(2,"0"); };
    set("cd-d", d); set("cd-h", h); set("cd-m", m); set("cd-s", s);
  }
  tick();
  setInterval(tick, 1000);
}

/* ── SEARCH ── */
function initSearch() {
  const inp = document.querySelector(".search-input");
  const btn = document.querySelector(".search-btn");
  function go() {
    const v = inp?.value.trim();
    if (v) window.location.href = "products.html?q=" + encodeURIComponent(v);
  }
  inp?.addEventListener("keydown", e => { if (e.key === "Enter") go(); });
  btn?.addEventListener("click", go);
}

/* ── PRODUCT CARD BUILDER ── */
function buildCard(p) {
  const price  = p.salePrice || p.price;
  const pct    = p.salePrice ? Math.round((1 - p.salePrice / p.price) * 100) : 0;
  const badge  = p.salePrice
    ? `<span class="pc-badge-sale">Save ${pct}%</span>`
    : p.isNew ? `<span class="pc-badge-new">NEW</span>` : "";
  const soldOverlay = !p.inStock ? `<div class="pc-soldout">Sold Out</div>` : "";
  const stockTxt = p.inStock
    ? `<div class="pc-stock in">In Stock ✓</div>`
    : `<div class="pc-stock out">Sold Out ✗</div>`;
  const wlActive = isInWishlist(p.id) ? "active" : "";
  const atcDisabled = !p.inStock ? "disabled" : "";
  const origHtml = p.salePrice
    ? `<span class="pc-orig" data-orig-price="${p.price}">${formatPrice(p.price)}</span>` : "";

  return `
  <div class="product-card" data-product-id="${p.id}">
    <div class="pc-img">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      ${badge}${soldOverlay}
      <button class="pc-wishlist ${wlActive}" data-wl-id="${p.id}"
        onclick="toggleWishlist(${p.id},'${esc(p.name)}',${price},'${p.image}','${esc(p.category)}')">
        <svg viewBox="0 0 24 24" fill="${wlActive ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
          <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
        </svg>
      </button>
    </div>
    <div class="pc-body">
      <div class="pc-cat">${p.category}</div>
      <div class="pc-name">${p.name}</div>
      <div class="pc-price-row">
        <span class="pc-price" data-price="${price}">${formatPrice(price)}</span>
        ${origHtml}
      </div>
      ${stockTxt}
      <button class="pc-atc" ${atcDisabled}
        onclick="addToCart(${p.id},'${esc(p.name)}',${price},'${p.image}','${esc(p.category)}')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
          <line x1="3" y1="6" x2="21" y2="6"/>
          <path d="M16 10a4 4 0 01-8 0"/>
        </svg>
        Add to Cart
      </button>
    </div>
  </div>`;
}

function esc(s) { return String(s).replace(/'/g, "\\'"); }

/* ── INIT ── */
document.addEventListener("DOMContentLoaded", function () {
  // badges
  updateCartBadge();
  updateWishlistBadge();

  // language/currency buttons
  document.querySelectorAll("[data-lang-btn]").forEach(b => {
    b.classList.toggle("active", b.dataset.langBtn === currentLang);
    b.addEventListener("click", () => setLang(b.dataset.langBtn));
  });
  document.querySelectorAll("[data-cur-btn]").forEach(b => {
    b.classList.toggle("active", b.dataset.curBtn === currentCurrency);
    b.addEventListener("click", () => setCurrency(b.dataset.curBtn));
  });

  // modal overlays
  document.querySelectorAll(".modal-overlay").forEach(o => {
    o.addEventListener("click", e => { if (e.target === o) o.classList.remove("open"); });
  });

  // forms
  document.getElementById("loginForm")?.addEventListener("submit", e => {
    e.preventDefault(); closeModal("loginModal"); showToast("Welcome back!", "success");
  });
  document.getElementById("signupForm")?.addEventListener("submit", e => {
    e.preventDefault(); closeModal("signupModal"); showToast("Account created! Welcome.", "success");
  });
  document.getElementById("nlForm")?.addEventListener("submit", e => {
    e.preventDefault(); showToast("Subscribed! Check your inbox for 15% off.", "success");
    e.target.reset();
  });

  // search
  initSearch();

  // carousel
  initCarousel();

  // active nav
  const page = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-link").forEach(a => {
    if ((a.getAttribute("href") || "") === page) a.classList.add("active");
  });

  // apply saved lang/currency
  setLang(currentLang);
  setCurrency(currentCurrency);
});
